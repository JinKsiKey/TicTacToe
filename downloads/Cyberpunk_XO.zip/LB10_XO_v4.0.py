import tkinter as tk
from tkinter import messagebox, ttk
from functools import partial
from database import *

class CyberpunkTicTacToe:
    def __init__(self, root):
        self.root = root
        self.root.title("Киберпанк XO")
        self.root.configure(bg='#000000')
        self.root.resizable(False, False)

        # Стили
        self.bg_color = '#000000'
        self.neon_pink = '#FF00FF'
        self.neon_blue = '#00FFFF'
        self.font = ('Courier New', 40, 'bold')
        self.button_font = ('Consolas', 14, 'bold')
        self.glow_effect = {'activebackground': self.neon_pink, 'bd': 3, 'relief': 'ridge'}

        # Инициализация БД
        init_db()
        self.player_id = register_player("Player", False)
        self.computer_id = register_player("Computer", True)
        self.current_game_id = start_game(self.player_id, self.computer_id)

        # Настройки игры
        self.player_symbol = 'X'
        self.computer_symbol = 'O'
        self.current_player = 'X'
        self.board = [' '] * 9

        # Создание интерфейса
        self._setup_ui()
        self.center_window(550, 550)

        # Обработчик закрытия
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # Старт игры для компьютера, если нужно
        if self.computer_symbol == 'X':
            self.root.after(500, self.computer_move)


    def _setup_ui(self):
        """Создание интерфейса"""
        # Фрейм управления
        control_frame = tk.Frame(self.root, bg=self.bg_color)
        control_frame.pack(pady=15)

        # Кнопки выбора символа
        self.symbol_frame = tk.Frame(control_frame, bg=self.bg_color)
        self.symbol_frame.pack(side=tk.LEFT, padx=20)

        tk.Label(self.symbol_frame, text="Играть за:", fg=self.neon_blue,
                 bg=self.bg_color, font=self.button_font).pack()

        self.x_button = tk.Button(self.symbol_frame, text="X", font=self.button_font,
                                  fg=self.neon_pink, bg=self.bg_color, **self.glow_effect,
                                  command=partial(self.change_symbol, 'X'))
        self.x_button.pack(side=tk.LEFT, padx=5)

        self.o_button = tk.Button(self.symbol_frame, text="O", font=self.button_font,
                                  fg=self.neon_blue, bg=self.bg_color, **self.glow_effect,
                                  command=partial(self.change_symbol, 'O'))
        self.o_button.pack(side=tk.LEFT, padx=5)

        # Кнопки управления
        button_style = {'font': self.button_font, 'bg': self.bg_color,
                        'fg': self.neon_pink, 'activebackground': '#222222'}

        tk.Button(control_frame, text="Новая игра", **button_style,
                  command=self.reset_game).pack(side=tk.LEFT, padx=10)
        tk.Button(control_frame, text="Статистика", **button_style,
                  command=self.show_stats).pack(side=tk.LEFT, padx=10)

        # Игровое поле
        self.board_frame = tk.Frame(self.root, bg=self.neon_blue)
        self.board_frame.pack(pady=20, padx=20)

        self.buttons = []
        for i in range(9):
            btn = tk.Button(self.board_frame, text='', font=self.font, width=3, height=1,
                            bg='#111111', fg=self.neon_pink, activebackground='#222222',
                            relief='flat', bd=4, highlightthickness=2,
                            highlightbackground=self.neon_blue)
            row, col = divmod(i, 3)
            btn.grid(row=row, column=col, padx=2, pady=2)
            btn.config(command=lambda idx=i: self.on_click(idx))
            self.buttons.append(btn)

        # Статусная панель
        self.status_label = tk.Label(self.root, text=f"ВАШ ХОД ({self.player_symbol})",
                                     fg=self.neon_pink, bg=self.bg_color, font=('Consolas', 18, 'bold'))
        self.status_label.pack(pady=15)

    def on_close(self):
        """Сохранение данных перед закрытием"""
        self.save_stats()
        self.root.destroy()

    def center_window(self, width, height):
        """Центрирование окна"""
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')

    def save_stats(self):
        """Сохранение статистики (без сообщения)"""
        conn = create_connection()
        if conn:
            conn.commit()
            conn.close()

    def change_symbol(self, symbol):
        """Смена символа игрока"""
        if symbol == self.player_symbol:
            return

        self.player_symbol = symbol
        self.computer_symbol = 'O' if symbol == 'X' else 'X'
        self.reset_game()

    def reset_game(self):
        """Перезапуск игры"""
        self.current_game_id = start_game(self.player_id, self.computer_id)
        self.board = [' '] * 9
        self.current_player = 'X'

        for button in self.buttons:
            button.config(text='', state=tk.NORMAL, bg='#111111')

        if self.computer_symbol == 'X':
            self.status_label.config(text="SAAI думает...")
            self.root.after(500, self.computer_move)
        else:
            self.status_label.config(text=f"Ваш ход ({self.player_symbol})")

    def on_click(self, idx):
        """Ход игрока"""
        if self.board[idx] == ' ' and self.current_player == self.player_symbol:
            self.make_move(idx, self.player_symbol)
            record_move(self.current_game_id, self.player_id, idx, self.player_symbol)

            if self.check_winner(self.player_symbol):
                messagebox.showinfo("Победа!", "Вы победили!")
                end_game(self.current_game_id, 'Победа')
                self.reset_game()
                return

            if self.is_board_full():
                messagebox.showinfo("Ничья!", "Игра завершена!")
                end_game(self.current_game_id, 'Ничья')
                self.reset_game()
                return

            self.current_player = self.computer_symbol
            self.status_label.config(text="Компьютер думает...")
            self.root.after(1000, self.computer_move)

    def computer_move(self):
        """Ход компьютера"""
        if self.current_player != self.computer_symbol:
            return

        best_move = self.get_best_move()
        self.make_move(best_move, self.computer_symbol)
        record_move(self.current_game_id, self.computer_id, best_move, self.computer_symbol)

        if self.check_winner(self.computer_symbol):
            messagebox.showinfo("Поражение", "Компьютер победил!")
            end_game(self.current_game_id, 'Поражение')
            self.reset_game()
            return

        if self.is_board_full():
            messagebox.showinfo("Ничья!", "Игра завершена!")
            end_game(self.current_game_id, 'Ничья')
            self.reset_game()
            return

        self.current_player = self.player_symbol
        self.status_label.config(text=f"Ваш ход ({self.player_symbol})")

    def make_move(self, idx, symbol):
        """Обновление доски"""
        color = self.neon_pink if symbol == 'X' else self.neon_blue
        self.board[idx] = symbol
        self.buttons[idx].config(text=symbol, fg=color, state=tk.DISABLED, disabledforeground=color)

    def check_winner(self, player):
        """Проверка победы"""
        wins = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6],
                [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
        return any(all(self.board[i] == player for i in combo) for combo in wins)

    def is_board_full(self):
        """Проверка на ничью"""
        return ' ' not in self.board

    def get_empty_positions(self):
        """Свободные клетки"""
        return [i for i, spot in enumerate(self.board) if spot == ' ']

    def get_best_move(self):
        """Логика ИИ"""
        empty = self.get_empty_positions()

        # Попытка победить
        for combo in [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6],
                      [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]:
            cells = [self.board[i] for i in combo]
            if cells.count(self.computer_symbol) == 2 and cells.count(' ') == 1:
                return combo[cells.index(' ')]

        # Блокировка игрока
        for combo in [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6],
                      [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]:
            cells = [self.board[i] for i in combo]
            if cells.count(self.player_symbol) == 2 and cells.count(' ') == 1:
                return combo[cells.index(' ')]

        # Центр и углы
        if 4 in empty: return 4
        corners = [0, 2, 6, 8]
        empty_corners = [c for c in corners if c in empty]
        if empty_corners: return empty_corners[0]
        return empty[0]

    def show_stats(self):
        """Отображение статистики"""
        stats_window = tk.Toplevel(self.root)
        stats_window.title("Статистика")
        stats_window.configure(bg='#000000')
        stats_window.geometry("400x106")

        conn = create_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT result, COUNT(*) FROM Games 
                    WHERE player_id = ? AND result IS NOT NULL
                    GROUP BY result
                ''', (self.player_id,))

                tree = ttk.Treeview(stats_window, columns=('Result', 'Count'), show='headings', style='Cyber.Treeview')
                tree.heading('Result', text='Результат')
                tree.heading('Count', text='Количество')
                tree.pack(fill='both', expand=True, padx=10, pady=10)

                style = ttk.Style()
                style.configure('Cyber.Treeview', background='#111111', foreground=self.neon_blue,
                                fieldbackground='#000000', font=('Consolas', 12))

                for row in cursor.fetchall():
                    tree.insert('', 'end', values=row)

            except Error as e:
                messagebox.showerror("Ошибка", f"Ошибка базы данных: {e}")
            finally:
                conn.close()


if __name__ == "__main__":
    root = tk.Tk()
    root.iconbitmap('cyberpunk_icon.ico')
    app = CyberpunkTicTacToe(root)
    root.mainloop()